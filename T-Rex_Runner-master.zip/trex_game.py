import sys

import pygame.time

from extra import *
from settings import Settings
from trex_game_sprites import *


class TRexRunner:
    """T-Rex Game class"""

    def __init__(self):
        """Инициализация игрового класса T-Rex и большинства его зависимостей"""
        # addition variable is used to add to the current score
        # addition is increased by 4 when player kills a cactus,
        # and it is increased by 8 when player kills a bird
        self.addition = 0

        pygame.init()
        self.settings = Settings()
        self.screen = pygame.display.set_mode(self.settings.screen_dimen)
        self.screen_rect = self.screen.get_rect()
        pygame.display.set_caption("T-Rex Runner")
        game_icon = pygame.image.load("assets/t-rex/t-rex-7.png")
        pygame.display.set_icon(game_icon)
        # init game sounds
        self.start_jump_sound = pygame.mixer.Sound("assets/sounds/start_or_jump.wav")
        self.crash_sound = pygame.mixer.Sound("assets/sounds/crash.wav")
        self.milestone_sound = pygame.mixer.Sound("assets/sounds/milestone.wav")
        self.shoot_sound = pygame.mixer.Sound("assets/sounds/shoot.wav")
        self.first_shot_sound = pygame.mixer.Sound("assets/sounds/shot_hit_1.wav")
        self.second_shot_sound = pygame.mixer.Sound("assets/sounds/shot_hit_2.wav")
        self.clock = pygame.time.Clock()
        # отслеживание статуса игры. сначала она не запускается, пока игрок не нажмет какую-либо клавишу
        self.started = False
        # переменные начального экрана
        self.show_press_any_key_to_start = True
        self.start_text = StartText(self, "press any key to start")
        # счет
        self.score = Score(self)
        # индикатор пуль
        self.bullet_text = BulletsCount(self)
        # кнопка начать сначала
        self.button = Button(self)
        # количество кактусов генерируется случайным образом для создания группы кактусовых спрайтов
        self.cacti_count = 0
        # инициализация спрайтов

        # земля
        self._init_ground()
        self.attaching_ground = False

        # t-rex
        self._init_trex()
        # облака
        self._init_clouds()
        # кактусы
        self._init_cacti()
        # звезда
        self._init_stars()
        # птица
        self._init_birds()
        # луна
        self._init_moon()
        # пули
        self._init_bullet()
        # индикатор загрузки пуль
        self.bullet_loading_indicator = BulletLoadingIndicator(self)

    def start_game(self):
        """Запускает игру"""
        while True:
            # выполняется до тех пор, пока trex не столкнётся с каким-либо препятствием
            if not self.trex.collided:
                self.screen.fill(self.settings.screen_background_color)
                self._show_press_any_key_to_start_text()
                self._draw_sprites()
                self._create_indicator()
                self.bullet_text.update(self.get_bullet_count())
            else:
                # если это произойдет и trex столкнется, показывает экран завершения игры
                self._show_game_over_text_and_play_again()

            self.trex_group.draw(self.screen)
            self._listen_for_events()
            pygame.display.flip()
            self.clock.tick(60)

    def _init_trex(self):
        """Инициализируем trex и размещаем его соответствующим образом поверх земли"""
        self.trex_group = pygame.sprite.Group()
        sprites_y = self.ground_group.sprites()[0].rect.y - self.ground_group.sprites()[0].rect.height
        self.trex = TRex(self, sprites_y)
        self.trex_group.add(self.trex)

    def _init_ground(self):
        """Инициализируем землю и размещаем её соответственно на x=0 и y = 75% высоты экрана"""
        self.ground_group = pygame.sprite.Group()
        self._create_ground()

    def _init_clouds(self):
        """рандомная инициализация облаков и размещение их между верхушками облаков и землей
Мы передаем значение 250 * i в качестве координаты x каждому облаку только для того, чтобы между ними была пустота"""
        self.cloud_group = pygame.sprite.Group()
        for i in range(1, 4):
            self._create_cloud(i * 250)

    def _init_cacti(self):
        """Инициализация группы кактусов"""
        self.cactus_group = pygame.sprite.Group()

    def _init_stars(self):
        """Инициализация группы звёзд"""
        self.star_group = pygame.sprite.Group()

    def _init_birds(self):
        """Инициализация группы птиц"""
        self.bird_group = pygame.sprite.Group()

    def _init_moon(self):
        """Инициализация группы луна"""
        self.moon_group = pygame.sprite.Group()

    def _init_bullet(self):
        """Инициализация группы пули"""
        self.bullet_group = pygame.sprite.Group()

    def _draw_sprites(self):
        """Рисовка большинства спрайтов"""
        self.ground_group.draw(self.screen)
        self.moon_group.draw(self.screen)
        self.star_group.draw(self.screen)
        self.cloud_group.draw(self.screen)
        self.cactus_group.draw(self.screen)
        self.bird_group.draw(self.screen)
        self.bullet_group.draw(self.screen)
        # если игра не запущена или приостановлена из-за столкновения trex, прекращается обновление спрайтов
        if self.started:
            self._update_sprites()

    def _update_sprites(self):
        """Обновление спрайтов и большинства элементов экрана"""
        # получение текущего времени в миллисекундах для отображения / обновления некоторых спрайтов
        current_time = pygame.time.get_ticks()
        # преобразование текущего времени для выбора компакт-дисков
        self.current_time_int_deci = int((current_time - self.start_time) * 0.01)
        # обновление счёта
        self.score.update_score(self.current_time_int_deci + self.addition, lambda: self.milestone_sound.play())
        # отображение только птиц через 450 секунд
        show_bird = self.current_time_int_deci > 450
        # показ кактусов через 40 секунд после начала игры
        forty_deci_passed = self.current_time_int_deci > 40
        show_cacti = forty_deci_passed and not self.cacti_count
        # запуск создания звездочек через 600 миллисекунд и если список пуст
        # мы также рандомизируем создание звезд, создавая их только в том случае, если время принятия решения
        # делится на 1,5, поэтому мы создаем их с дециметром 600, 900 и т.д.
        should_create_stars = (self.current_time_int_deci // 100) % 1.5 == 0 and not self.star_group.sprites()
        six_hundred_deci_passed = self.current_time_int_deci > 600
        #Показ луны после 850 очокв, и если они делятся на 300
        show_moon = self.current_time_int_deci > 850 and self.current_time_int_deci % 300 == 0
        #  использование этой переменной, чтобы решить, показывать ли кактус или птицу
        # где 0 = показать кактус, а 1 - птицу
        # она начнется с нуля, и как только мы покажем птиц, мы сгенерируем её случайным образом
        if show_bird:
            sprite_type = random.randint(0, 1)
        else:
            sprite_type = 0

        # обновить trex
        self.trex.update()
        self._check_collisions()

        # обновить землю
        for ground in self.ground_group.sprites():
            # проверка, если справа от нашей земли меньше, чем справа от экрана
            # затем мы создаем еще одну землю и прикрепляем левую часть новой земли к
            # правой части старой, чтобы создать бесконечную землю
            if ground.should_attach_another_ground() and len(self.ground_group) <= 1:
                self._create_ground(right=ground.rect.right)
            ground.update()

        # обновление облаков
        for cloud in self.cloud_group.sprites():
            cloud.update()
        if len(self.cloud_group.sprites()) < 3:
            self._create_cloud()

        # обновление звёзд
        for star in self.star_group.sprites():
            star.update()
        if six_hundred_deci_passed and should_create_stars:
            stars_count = random.randint(1, 3)
            for i in range(stars_count):
                # так же, как и облакам, мы передаем значение 250 * i  как координату x для каждой звезды, просто чтобы иметь пустоту
                # между ними
                star = Star(self, i * 250)
                self.star_group.add(star)
        # создание кактусов, если тип спрайта равен 0, что указывает на создание кактусов, а группа птиц - emtpy
        if sprite_type == 0 and not self.bird_group.sprites():
            if show_cacti:
                self._create_cacti()
            # продолжение создания кактусов до тех пор, пока длина группы кактусов не станет меньше сгенерированного количества
            if len(self.cactus_group.sprites()) < self.cacti_count:
                self._create_cacti()
        # опять же, если тип спрайта равен 1, тогда мы должны создать птицу
        elif sprite_type == 1 and not self.cactus_group.sprites():
            if not self.bird_group.sprites():
                # передача пары значений y для размещения птиц в соответствии с 3 местами
                # (перед головой трекса, перед ногой трекса, над головой трекса)
                top_of_bird = self.ground_group.sprites()[0].rect.y - self.trex.rect.height - \
                              self.ground_group.sprites()[0].rect.height * 0.75
                bottom_of_ground = self.ground_group.sprites()[0].rect.bottom
                top_of_trex = self.trex.rect.top
                list_of_ys = [top_of_bird, bottom_of_ground, top_of_trex]
                bird = Bird(self, list_of_ys)
                self.bird_group.add(bird)

        # обновление Кактусов
        for cactus in self.cactus_group.sprites():
            cactus.update()
        # обновление птиц
        for bird in self.bird_group.sprites():
            bird.update()

        # обновление луны
        for moon in self.moon_group.sprites():
            moon.update()
        if show_moon and not self.moon_group.sprites():
            moon = Moon(self)
            self.moon_group.add(moon)

        # обновление пуль
        for bullet in self.bullet_group.sprites():
            bullet.update()

    def _create_ground(self, right=None):
        """создание бесконечной земли"""
        ground = Ground(self)
        if right is not None:
            ground.set_left(right)
        self.ground_group.add(ground)

    def _create_cloud(self, x=0):
        """Создание облаков"""
        cloud = Cloud(self, x)
        self.cloud_group.add(cloud)

    def _create_cacti(self):
        """Создание кактусов"""
        # отслеживание идентификатора каждого кактуса, чтобы иметь уникальные кактусы в каждой группе
        ids = []
        self.cacti_count = random.choices([1, 2, 3, 4], [.4, .2, .1, .1])[0]
        # вычисление ширины предыдущего кактуса и x для увеличения xpos следующего кактуса
        prev_x = 0
        prev_width = 0
        for _ in range(self.cacti_count):
            # вычисляем кактус y, чтобы поместить его на землю
            cactus_y = self.ground_group.sprites()[0].rect.y + self.ground_group.sprites()[0].rect.height / 2
            # вычисляя cactus x, просто поместим их в группу, как описано в Cactus class
            cactus_x = prev_x + prev_width
            cactus = Cactus(self, cactus_y, cactus_x)
            # проверяем, есть ли у нас в группе одинаковые кактусы. Если да, то удаляем его и создаем новый
            # Таким образом, каждый кактус в каждой группе уникален
            while cactus.id in ids:
                cactus = Cactus(self, cactus_y, cactus_x)
            ids.append(cactus.id)
            prev_x = cactus.rect.x
            prev_width = cactus.rect.width
            self.cactus_group.add(cactus)

    def _listen_for_events(self):
        """события"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if self.show_press_any_key_to_start:
                    # сброс времени на текущее время, когда пользователь впервые запускает игру, поэтому мы начинаем с 0 секунд
                    self.start_time = pygame.time.get_ticks()
                    self.start_jump_sound.play()
                    self.show_press_any_key_to_start = False
                self.started = True
                if event.key == pygame.K_UP:
                    if not self.trex.jumping:
                        self.start_jump_sound.play()
                    self.trex.jumping = True
                    self.trex.crouching = False
                elif event.key == pygame.K_DOWN:
                    self.trex.jumping = False
                    self.trex.crouching = True
                if event.key == pygame.K_SPACE:
                    self._fire_bullet()
            elif event.type == pygame.KEYUP:
                self.trex.crouching = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                retry_clicked = self.button.rect.collidepoint(mouse_pos)
                if self.trex.collided and retry_clicked:
                    self._reset()

    def _check_collisions(self):
        """Проверка столкновений между пулями и птицами или кактусами, а также столкновений trex с птицами или кактусами"""
        # столкновения trex
        cactus_hits_trex = pygame.sprite.spritecollide(
            self.trex,
            self.cactus_group,
            True,
            pygame.sprite.collide_mask)
        bird_hits_trex = pygame.sprite.spritecollide(
            self.trex,
            self.bird_group,
            True,
            pygame.sprite.collide_mask)

        if bird_hits_trex or cactus_hits_trex:
            self.crash_sound.play()
            self.trex.collide()
        # столкновения пуль

        # при первом столкновении пули с птицей/ кактусом изображение спрайта устанавливается на поврежденные спрайты
        # и вторая пуля, убивающая спрайта, соответственно дает игроку очки
        bullet_hit_bird = pygame.sprite.groupcollide(
            self.bullet_group,
            self.bird_group,
            True,
            False,
            pygame.sprite.collide_mask)

        for bullet in bullet_hit_bird:
            for bird in bullet_hit_bird[bullet]:
                if bird.current_list == bird.damaged_bird_sprites:
                    bird.kill()
                    self.addition += 8
                    self.second_shot_sound.play()
                    return
                bird.set_damaged()
                self.first_shot_sound.play()

        bullet_hit_cactus = pygame.sprite.groupcollide(
            self.bullet_group,
            self.cactus_group,
            True,
            False,
            pygame.sprite.collide_mask)
        for bullet in bullet_hit_cactus:
            for cactus in bullet_hit_cactus[bullet]:
                if cactus.image == cactus.damaged_image:
                    cactus.kill()
                    self.addition += 4
                    self.second_shot_sound.play()
                    return
                cactus.set_damaged()
                self.first_shot_sound.play()

    def _show_game_over_text_and_play_again(self):
        """Создает текст "игра окончена" и кнопку начать сначала"""
        game_over = StartText(self, "game over", 30)
        x = self.screen_rect.centerx
        y1 = self.screen_rect.height / 3
        y2 = self.screen_rect.height - y1
        game_over.blit(x, y1)
        self.button.blit(x, y2)

    def _reset(self):
        """Сбрасывает большинство игровых элементов и настроек, а также проверяет лучший результат"""
        self.start_jump_sound.play()
        self.start_time = pygame.time.get_ticks()
        self.addition = 0
        self.score.fetch_high_score()
        self._drop_sprites()
        self.trex.reset()
        self.settings.reset_difficulty()

    def _drop_sprites(self):
        """Сбрасывает спрайты"""
        self.cactus_group.empty()
        self.bird_group.empty()
        self.bullet_group.empty()
        self.star_group.empty()
        self.moon_group.empty()

    def _fire_bullet(self):
        """Создает пули и стреляет ими только в том случае, если игра еще не закончена и если у нас достаточно места для большего количества пуль"""
        if self.settings.bullet_count > len(self.bullet_group.sprites()) and not self.trex.collided:
            bullet = Bullet(self)
            self.bullet_group.add(bullet)
            self.shoot_sound.play()

    def _show_press_any_key_to_start_text(self):
        """Создает начальный текст на стартовом экране"""
        if self.show_press_any_key_to_start:
            self.start_text.blit(self.screen_rect.width / 2, self.screen_rect.height / 2)
            self.start_text.update()

    def _create_indicator(self):
        """Настройка индикатора заряжания в соответствии с процентом расстояния первой пули от конца
экрана тогда и только тогда, когда ваш пистолет пуст
        """
        if self.get_bullet_count() == 0:
            percentage = 1 - ((self.settings.screen_dimen[0] - self.bullet_group.sprites()[-1].rect.x) /
                              self.settings.screen_dimen[0])
            self.bullet_loading_indicator.update(percentage)

    def get_bullet_count(self):
        """Возвращает количество пуль"""
        return abs(len(self.bullet_group.sprites()) - self.settings.bullet_count)

