from trex_game import *
game = TRexRunner()
game.start_game()
